extern "C" {
    SEXP gpuMatMult(SEXP a, SEXP b);
    SEXP cpuMatMult(SEXP a, SEXP b);
}
